


var method_get = "GET";
var method_post = "POST";

var base_url = global_base_url;

//var agent_desk_no  = agent_phone_no;
//var admin_id = admin_id;


//var admin_controller = base_url+ "admin/";


var image_base_url = base_url+ "assets/images/";

var www_controller =  base_url+ "www/www/";

var mobile_controller  = base_url+ "mobile/mobile";


var www_api_url = base_url+ "api/";

//setting 'diner_id' in the header now
//var diner_id = global_diner_id;
var diner_id = '';

var mobile_api_url  = base_url+ "mobile_api/";