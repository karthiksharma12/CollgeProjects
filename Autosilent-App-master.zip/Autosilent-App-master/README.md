# Autosilent-App
Keeps your Mobile in silent mode automatically
