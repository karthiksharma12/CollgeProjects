$(document).ready(function(){
    $(".work_container").hide()
});
function hidework(){
    $('.work_rel>div').addClass('work_hidden');
    $('.work_rel>div').removeClass('work_content');  
    setTimeout(function(){$('.work_container div').hide();$(".work_container").hide();},500);
    
}
function showwork(wsid){
    var content = $("#ws_"+wsid).html();
    $('.work_rel>div.work_hidden').html(content);
    $('.work_rel>div.work_hidden').append("<div class='work_response'></div>");
    $('.work_rel>div').show();
    $(".work_container").show();
    setTimeout(function(){$('.work_rel>div').removeClass('work_hidden');},100);
    $('.work_rel>div').addClass('work_content');    
    
}

function workreg(id){
    $.ajax(
        {
            url:'/eventreg/workreg',
            data:{
                    'id':id,
                    },
            success:function(data){
                $(".work_response").html(data);
            }
        }
    );
}