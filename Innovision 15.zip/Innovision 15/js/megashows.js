function changeMS(msInd){
  $(".heading-ms-visible").removeClass( "heading-ms-visible" ).addClass( "heading-ms" );
  $("#ms_heading_"+msInd).removeClass("heading-ms").addClass("heading-ms-visible");
  $("#megashow_text p").fadeOut(300, function() {
    $(this).html(megashowDesc[msInd-1]).fadeIn(300);
  });
}

var f=0;

$(document).ready(function() {
    trans(1);
});

function trans(id){

	if(f!=0) {close(f); }
	console.log(id);
	var imgid='#mega_imag'+id;
	var textid='#mega_text'+id;
	var font='#mega_'+id;
	console.log(imgid);
	$(imgid).fadeIn();
	$(textid).show();
	$(font).css("color","rgba(54,75,108,1)");
//$(textid).animate({left: "50%"},1000);console.log('text perfect');
f=id;
}

function close(id){

	if(f!=0){

		var imgid='#mega_imag'+id;
	var textid='#mega_text'+id;
	var font='#mega_'+id;
	console.log(imgid);
	$(imgid).fadeOut();
	$(textid).hide();
	$(font).css("color","white");
f=0;
$('#mega_text').fadeIn(1000);
	}
}

function closeall(){

	if(f!=0){

		id=f;
		close(id);
		f=0;
		$('span').hide();
	}
}